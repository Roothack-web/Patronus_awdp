#!/bin/bash
cp -f index.php /var/www/html/index.php
echo "Patch applied successfully"
