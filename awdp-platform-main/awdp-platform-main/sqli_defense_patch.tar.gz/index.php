<?php
error_reporting(0);
session_start();

$db = null;
try {
    $db = new mysqli('sqli_db', 'sroot', 'Sr00t_P@ssw0rd_2024!', 'news_db');
    if ($db->connect_error) throw new Exception();
    $db->set_charset('utf8mb4');
} catch (Exception $e) {
    die('<div style="text-align:center;padding:50px;font-family:sans-serif;"><h2>Database Connection Failed</h2><p>Please wait a moment and refresh...</p></div>');
}

$article = null;
$error = false;

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $sql = "SELECT a.*, c.name AS category_name FROM articles a
            LEFT JOIN categories c ON a.category_id = c.id
            WHERE a.id = $id";
    $result = $db->query($sql);
    if ($result && $result->num_rows > 0) {
        $article = $result->fetch_assoc();
    } else {
        $error = true;
    }
}

$latest_articles = [];
$res = $db->query("SELECT a.id, a.title, a.author, a.view_count, a.image_url, a.created_at, c.name AS category_name
                    FROM articles a LEFT JOIN categories c ON a.category_id = c.id
                    ORDER BY a.created_at DESC LIMIT 6");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $latest_articles[] = $row;
    }
}
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>每日资讯 - 让信息创造价值</title>
</head>
<body>
    <?php if ($article !== null): ?>
        <h1><?php echo htmlspecialchars($article['title']); ?></h1>
        <div><?php echo nl2br(htmlspecialchars($article['content'])); ?></div>
        <a href="/">← 返回首页</a>
    <?php elseif ($error): ?>
        <h3>该文章不存在或已被删除</h3>
        <a href="/">← 返回首页</a>
    <?php else: ?>
        <h2>最新资讯</h2>
        <?php foreach ($latest_articles as $a): ?>
            <div>
                <a href="/?id=<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['title']); ?></a>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
